<script setup>
 //評論串接網址 https://cwpeng.github.io/live-records-samples/data/reviews.json

import RevieList from "./ReviewList.vue";
import {onMounted,ref} from "vue";
let reviews=ref(null);
onMounted(async function(){
    let response=await fetch("https://cwpeng.github.io/live-records-samples/data/reviews.json");
    let  data=await response.json();
    reviews.value=data;

});
</script>


<template>
    <div v-if="reviews===null">資料載入中</div>
    <RevieList v-else  :reviews="reviews"></RevieList>
</template>

<style scoped>


</style>