<script setup>
 //後端提供串接資料網址 https://cwpeng.github.io/live-records-samples/data/products.json

 import {onMounted, ref} from "vue";
 import ProductList from "./ProductList.vue";

 let products=ref(null);//建立響應是狀態 products,一開始是空值 null
 //組件掛載完成後,開始呼叫 fetch串接後端資料

 onMounted(async function(){
    let response=await fetch("https://cwpeng.github.io/live-records-samples/data/products.json");
    let data=await response.json();
    products.value=data;
 });
 </script>

 <template>
    
    <div v-if="products===null">資料載入中</div>
    <ProductList v-else :products="products"></ProductList>
 </template>

 <style scoped>
 
 </style>