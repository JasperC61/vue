<script setup>
  
  import {onMounted,onUnmounted,ref} from "vue";
  
  let text=ref("主要網站內容");
  let changeText=function(){
     text.value="新網站內容";
  };
  //製作一個Counter功能
  let counter=ref(0);
  let scheduleId;
  //組件掛載時,設定每一秒加1動作
  onMounted(function(){
   scheduleId=window.setInterval(function(){
   console.log("每隔一秒鐘,數值加1");
   counter.value=counter.value+1;
   },1000);
   });
  //組件卸載時,清除掛載時設定動作
  onUnmounted(function(){
    //清除動作
    window.clearInterval(scheduleId);
  });
     
</script>

<template>
    
     <main>
     <div>{{counter}}</div>
     <div >{{text}}</div>
      <button @click="changeText">改變內容文字</button>
     
     </main>
</template>

<style scoped>
   
    main{padding:10px ;background-color:#dddddd;}

</style>
