<script setup>
  
  let level=0;
  let topics=["HTML","CSS","JavaScript","Vue.js"];
</script>

<template>
     <nav>基本導覽列</nav>
     <main>
     <div v-if="level==3">大美女</div>
     <div v-else-if="level==2">辣妹</div>
     <div v-else-if="level==1">美少女</div>
     <div v-else>
     <div>小女生</div>
      <ul>
       <li v-for="(name,index) in topics">
       {{index}}-{{name}}
       </li>
    
      </ul>
     </div>
     </main>
     
    
</template>

<style scoped>
    main{background-color:#dddddd;}
    
    
  
</style>
