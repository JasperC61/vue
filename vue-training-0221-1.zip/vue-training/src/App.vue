<script setup>
  //後端提供串接資料網址 https://cwpeng.github.io/live-records-samples/data/products.json
  import{onMounted,ref} from "vue";
  //建立響應是狀態 products,一開始是空值 null
  let products=ref(null);
  //組件掛在後,開始呼叫fetch串接後端資料
  onMounted(async function(){
     let response=await fetch("https://cwpeng.github.io/live-records-samples/data/products.json");
     let data=await response.json();
     products.value=data;
  });
</script>

<template>
   <div class="headline">產品列表</div>   
   <div v-if="products===null">資料載入</div>
   <div class="list" v-else>
     <div class="product" v-for="product in products">
     <div class="name">{{product.name}}</div>
     <div class="description">{{product.description}}</div>
     <div class="price">價格:{{product.price}}元</div>
     </div>
      
   </div>
</template>

<style scoped>
.headline{font-size:20px;font-weight:bold}
.list{line-height:1.5rem}
.product{padding:15px 0px;border-bottom:1px solid #01B468}
.product>.name{font-weight:bold}
</style>