<script setup>

  
</script>

<template>
     <nav>基本導覽列</nav>
     
      
</template>

<style scoped>
    nav{padding:10px;}
       
</style>
