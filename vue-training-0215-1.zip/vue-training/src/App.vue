<script setup>
  import NavComp from "./Nav.vue";
  import MainComp from "./Main.vue"; 
</script>

<template>
     <NavComp></NavComp>
     <MainComp></MainComp>
      
</template>

<style scoped>
   
   
</style>
