<script setup>
  import NavComp from "./Nav.vue";
  import MainComp from "./Main.vue"; 
</script>

<template>
     <NavComp title="這是Jasper標題部分"></NavComp>
     
     <MainComp color= "purple"
               backgroundColor="yellow">
     </MainComp>
      
</template>

<style scoped>
   
   
</style>
