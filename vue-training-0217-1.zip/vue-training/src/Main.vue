<script setup>
  
  import {ref} from "vue";
  let text=ref("主要網站內容");
  let changeText=function(){
     text.value="新網站內容";
  };

</script>

<template>
    
     <main>
     <div >{{text}}</div>
      <button @click="changeText">改變內容文字</button>
     
     </main>
</template>

<style scoped>
   
    main{padding:10px ;background-color:#dddddd;}

</style>
