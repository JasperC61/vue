<script setup>
  import{ref} from "vue";
  let title =ref("web site title");
  let handler=function(){
     
     title.value="new web site title";
  };

  
</script>

<template>
     <nav>基本導覽列</nav>
     <main>
    <div>{{title}}</div>
    <button @click="handler">按鈕</button>
     </main>
     
    
</template>

<style scoped>
    main{background-color:#dddddd;}
    
    
  
</style>
