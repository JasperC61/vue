<script setup>
  let handler =function(){
     console.log("click");
  };

  let mouseroverhandler=function(){
    console.log("mouse Over");
  };
</script>

<template>
     <nav>基本導覽列</nav>
     <main>
     <button @click="handler"  @mouseover="mouseroverhandler">按鈕</button>
     <a href="https://training.pada-x.com/">course web site</a>
     
     </main>
     
    
</template>

<style scoped>
    main{background-color:#dddddd;}
    
    
  
</style>
