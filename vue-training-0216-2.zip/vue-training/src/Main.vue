<script setup>
  
  import {ref} from "vue";
  let text=ref("主要網站內容");
  let change=function(){
     text.value="新網站內容";
  };

 let emit= defineEmits(["update"]);
 let updateParentSubtitle=function(){emit("update");};

  
  
</script>

<template>
    
     <main :style="{color:color,backgroundColor:backgroundColor}">

     <div @click="change">{{text}}</div>
      <button @click="updateParentSubtitle">改變第二標題內容</button>
      <!--<button @click="$emit('update')">改變第二標題內容</button>-->
     </main>
</template>

<style scoped>
   
    main{padding:10px ;background-color:#dddddd;}
     .content{color:red}
</style>
