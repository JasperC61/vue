<script setup>
  import NavComp from "./Nav.vue";
  import MainComp from "./Main.vue"; 
  import {ref} from "vue";
  let subtitle=ref("這是網站第二標題");
  let updatesubtitlet=function(){
    subtitle.value="這是新的第二標題";
  };
</script>

<template>
     <NavComp 
        title="這是Jasper標題部分"
        :subtitle="subtitle"
        ></NavComp>
     
     <MainComp color= "purple"
               backgroundColor="yellow"
               @update="updatesubtitlet">
     </MainComp>
      
</template>

<style scoped>
   
   
</style>
