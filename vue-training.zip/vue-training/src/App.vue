<script setup>
  
  let level=0;
  
</script>

<template>
     <nav>基本導覽列</nav>
     <main>
     <div v-if="level==3">大美女</div>
     <div v-else-if="level==2">辣妹</div>
     <div v-else-if="level==1">美少女</div>
     <div v-else>小女生</div>
     </main>
     
    
</template>

<style scoped>
    main{background-color:#dddddd;}
    
    
  
</style>
