<script setup>
  let title ="web site title";
  let handler=function(){
     console.log("click");
     title="new web site title";
  };

  
</script>

<template>
     <nav>基本導覽列</nav>
     <main>
    <div>{{title}}</div>
    <button @click="handler">按鈕</button>
     </main>
     
    
</template>

<style scoped>
    main{background-color:#dddddd;}
    
    
  
</style>
