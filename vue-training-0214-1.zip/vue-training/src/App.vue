<script setup>
//單行輸入框
  import {ref} from "vue";
  let content=ref("");
  let clearContent=function(){
     content.value="";
  };

//多選框
  let interests=ref([]);


//單選框

  let color=ref(null);
  
</script>

<template>
     <nav>基本導覽列</nav>
     <main>

     <h3>單行輸入框</h3>
     <input type="text"  v-model="content"/>
     <div>使用者輸入文字:{{content}}</div>
     <button @click="clearContent">清空輸入框</button>

     <h3>多選框</h3>
     角色扮演: <input type="checkbox" value="rpg" v-model="interests"/>
     即實策略: <input type="checkbox" value="rts" v-model="interests"/>
     動作遊戲: <input type="checkbox"  value="action" v-model="interests"/>
     <div>喜歡的遊戲類型:{{interests}}</div>
       <ul>
           <!--利用迴圈產生畫面樣板語法-->
          <li v-for="interest in interests">興趣:{{interest}}</li>
       </ul>
     


     <h3>單選框</h3>
     紅色:<input type="radio"  value="red" v-model="color" />
     橙色:<input type="radio" value="orange" v-model="color" />
     黃色:<input type="radio" value="yellow" v-model="color" />
     藍色:<input type="radio" value="blue"  v-model="color" />
    
      <div :class="color">使用人選擇的是 :{{color}}</div>



     <h3>下拉式選單</h3>

     
     </main>
     
    
</template>

<style scoped>
    .red{color:red}
    .green{color:green}
    .orange{color:orange}
    .yellow{color:yellow}
    main{background-color:#dddddd;}
    
    
  
</style>
